/***********************************************************************
FlashlightTool - Class for tools that add an additional light source
into an environment when activated.
Copyright (c) 2004-2008 Oliver Kreylos

This file is part of the Virtual Reality User Interface Library (Vrui).

The Virtual Reality User Interface Library is free software; you can
redistribute it and/or modify it under the terms of the GNU General
Public License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

The Virtual Reality User Interface Library is distributed in the hope
that it will be useful, but WITHOUT ANY WARRANTY; without even the
implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with the Virtual Reality User Interface Library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
02111-1307 USA
***********************************************************************/

#ifndef VRUI_FLASHLIGHTTOOL_INCLUDED
#define VRUI_FLASHLIGHTTOOL_INCLUDED

#include <Geometry/Ray.h>
#include <Geometry/OrthogonalTransformation.h>
#include <GL/GLLight.h>
#include <Vrui/Geometry.h>
#include <Vrui/Tools/UtilityTool.h>

/* Forward declarations: */
namespace Vrui {
class Lightsource;
class ToolManager;
}

namespace Vrui {

class FlashlightTool;

class FlashlightToolFactory:public ToolFactory
	{
	friend class FlashlightTool;
	
	/* Elements: */
	private:
	GLLight light; // OpenGL light source parameters for flashlight tools
	
	/* Constructors and destructors: */
	public:
	FlashlightToolFactory(ToolManager& toolManager);
	virtual ~FlashlightToolFactory(void);
	
	/* Methods: */
	virtual Tool* createTool(const ToolInputAssignment& inputAssignment) const;
	virtual void destroyTool(Tool* tool) const;
	};

class FlashlightTool:public UtilityTool
	{
	friend class FlashlightToolFactory;
	
	/* Elements: */
	private:
	static FlashlightToolFactory* factory; // Pointer to the factory object for this class
	Lightsource* lightsource; // Light source object allocated for this flashlight tool
	
	/* Transient state: */
	bool active; // Flag if the tool is currently active
	
	/* Constructors and destructors: */
	public:
	FlashlightTool(const ToolFactory* factory,const ToolInputAssignment& inputAssignment);
	virtual ~FlashlightTool(void);
	
	/* Methods: */
	virtual const ToolFactory* getFactory(void) const;
	virtual void buttonCallback(int deviceIndex,int buttonIndex,InputDevice::ButtonCallbackData* cbData);
	virtual void frame(void);
	};

}

#endif
